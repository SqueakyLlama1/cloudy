const slurs = ["slur4", "slur3", "slur2", "slur1"]; // hi willow here i didnt feel comfortable slurs

export const initCommands = async (client, command_prefix) => {
    client.on('messageCreate', async (message) => {
        if (message.author.bot) return;
        const botPinged = message.mentions.has(client.user);
        
        // credits
        if (botPinged && message.content.toLowerCase() === `credits`) {
            await message.reply(`Lead Developer - <@1374553820591292487> | Contributor - <@1083102195337150505>`);
            return;
        }
        
        // anti invite
        if (message.content.toLowerCase() === `https://discord.gg/`) {
            message.delete();
            await message.send(`<@${message.author}> You aren't able to send invite links in here.`);
            return;
        }
        
        // filter
        const containsBlockedWord = slurs.some(word => message.content.toLowerCase().includes(word.toLowerCase()));
        
        if (containsBlockedWord) {
            try {
                await message.send(`<@1463545149144563927> <@${message.author}> Filter Triggered.`);
                await message.delete();
            } catch (error) {
                console.error('Failed to delete or reply:', error);
            }
            return;
        }
    });
};