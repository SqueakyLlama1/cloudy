import * as fs from 'node:fs/promises';
import { Client, IntentsBitField } from 'discord.js';
import cron from 'node-cron';

import { initReminders } from './modules/reminders.js';
import { initEasterEggs } from './modules/easter_eggs.js';
import { initCommands } from  './modules/commands.js';

const command_prefix = `~`;

const client = new Client({
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent
    ]
});

client.on('clientReady', async () => {
    await initReminders(client);
    await initEasterEggs(client, command_prefix);
    await InitCommands(client, command_prefix)
});

async function startBot() {
    const secret = await fs.readFile('Cloudy-Secret.txt', {encoding:"utf-8"});
    client.login(secret);
}

startBot();